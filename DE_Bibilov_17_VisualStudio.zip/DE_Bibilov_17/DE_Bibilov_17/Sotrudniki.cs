﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DE_Bibilov_17
{
    public partial class Sotrudniki : Form
    {
        public Sotrudniki()
        {
            InitializeComponent();
        }

        private void sotrudnikiBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.sotrudnikiBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.dE_Bibilov_17DataSet);

        }

        private void Sotrudniki_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "dE_Bibilov_17DataSet.Sotrudniki". При необходимости она может быть перемещена или удалена.
            this.sotrudnikiTableAdapter.Fill(this.dE_Bibilov_17DataSet.Sotrudniki);

        }

        private void Vyhod_Click(object sender, EventArgs e)
        {
            Menu fm = new Menu ();
            fm.Show();
            this.Hide();
        }
    }
}
