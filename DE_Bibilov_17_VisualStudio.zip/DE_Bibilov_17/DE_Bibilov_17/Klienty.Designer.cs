﻿
namespace DE_Bibilov_17
{
    partial class Klienty
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label osnovnoi_materialLabel;
            System.Windows.Forms.Label stoimostLabel;
            System.Windows.Forms.Label vid_izdeliyaLabel;
            System.Windows.Forms.Label codLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Klienty));
            this.Posledniya = new System.Windows.Forms.Button();
            this.Sledyushaya = new System.Windows.Forms.Button();
            this.Predydushaya = new System.Windows.Forms.Button();
            this.Sohranit = new System.Windows.Forms.Button();
            this.Ydalit = new System.Windows.Forms.Button();
            this.Dobavit = new System.Windows.Forms.Button();
            this.Pervaya = new System.Windows.Forms.Button();
            this.Zagolovok = new System.Windows.Forms.Label();
            this.Nazad = new System.Windows.Forms.Button();
            this.Shapka = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.dE_Bibilov_17DataSet = new DE_Bibilov_17.DE_Bibilov_17DataSet();
            this.klientyBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.klientyTableAdapter = new DE_Bibilov_17.DE_Bibilov_17DataSetTableAdapters.KlientyTableAdapter();
            this.tableAdapterManager = new DE_Bibilov_17.DE_Bibilov_17DataSetTableAdapters.TableAdapterManager();
            this.codTextBox = new System.Windows.Forms.TextBox();
            this.fIOTextBox = new System.Windows.Forms.TextBox();
            this.dolzhnostTextBox = new System.Windows.Forms.TextBox();
            this.adresTextBox = new System.Windows.Forms.TextBox();
            osnovnoi_materialLabel = new System.Windows.Forms.Label();
            stoimostLabel = new System.Windows.Forms.Label();
            vid_izdeliyaLabel = new System.Windows.Forms.Label();
            codLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dE_Bibilov_17DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.klientyBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // osnovnoi_materialLabel
            // 
            osnovnoi_materialLabel.BackColor = System.Drawing.Color.Transparent;
            osnovnoi_materialLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            osnovnoi_materialLabel.Location = new System.Drawing.Point(242, 422);
            osnovnoi_materialLabel.Name = "osnovnoi_materialLabel";
            osnovnoi_materialLabel.Size = new System.Drawing.Size(256, 34);
            osnovnoi_materialLabel.TabIndex = 48;
            osnovnoi_materialLabel.Text = "Адрес:";
            osnovnoi_materialLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // stoimostLabel
            // 
            stoimostLabel.BackColor = System.Drawing.Color.Transparent;
            stoimostLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            stoimostLabel.Location = new System.Drawing.Point(331, 303);
            stoimostLabel.Name = "stoimostLabel";
            stoimostLabel.Size = new System.Drawing.Size(167, 34);
            stoimostLabel.TabIndex = 47;
            stoimostLabel.Text = "ФИО:";
            stoimostLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // vid_izdeliyaLabel
            // 
            vid_izdeliyaLabel.BackColor = System.Drawing.Color.Transparent;
            vid_izdeliyaLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            vid_izdeliyaLabel.Location = new System.Drawing.Point(260, 363);
            vid_izdeliyaLabel.Name = "vid_izdeliyaLabel";
            vid_izdeliyaLabel.Size = new System.Drawing.Size(238, 34);
            vid_izdeliyaLabel.TabIndex = 46;
            vid_izdeliyaLabel.Text = "Должность:";
            vid_izdeliyaLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // codLabel
            // 
            codLabel.BackColor = System.Drawing.Color.Transparent;
            codLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            codLabel.Location = new System.Drawing.Point(331, 244);
            codLabel.Name = "codLabel";
            codLabel.Size = new System.Drawing.Size(167, 34);
            codLabel.TabIndex = 45;
            codLabel.Text = "Код:";
            codLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Posledniya
            // 
            this.Posledniya.BackColor = System.Drawing.Color.Silver;
            this.Posledniya.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Posledniya.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Posledniya.Location = new System.Drawing.Point(864, 477);
            this.Posledniya.Name = "Posledniya";
            this.Posledniya.Size = new System.Drawing.Size(166, 50);
            this.Posledniya.TabIndex = 55;
            this.Posledniya.Text = "Последняя";
            this.Posledniya.UseVisualStyleBackColor = false;
            // 
            // Sledyushaya
            // 
            this.Sledyushaya.BackColor = System.Drawing.Color.Silver;
            this.Sledyushaya.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Sledyushaya.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Sledyushaya.Location = new System.Drawing.Point(635, 477);
            this.Sledyushaya.Name = "Sledyushaya";
            this.Sledyushaya.Size = new System.Drawing.Size(195, 50);
            this.Sledyushaya.TabIndex = 54;
            this.Sledyushaya.Text = "Следующая";
            this.Sledyushaya.UseVisualStyleBackColor = false;
            // 
            // Predydushaya
            // 
            this.Predydushaya.BackColor = System.Drawing.Color.Silver;
            this.Predydushaya.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Predydushaya.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Predydushaya.Location = new System.Drawing.Point(433, 477);
            this.Predydushaya.Name = "Predydushaya";
            this.Predydushaya.Size = new System.Drawing.Size(195, 50);
            this.Predydushaya.TabIndex = 53;
            this.Predydushaya.Text = "Предыдущая";
            this.Predydushaya.UseVisualStyleBackColor = false;
            // 
            // Sohranit
            // 
            this.Sohranit.BackColor = System.Drawing.Color.Silver;
            this.Sohranit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Sohranit.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Sohranit.Location = new System.Drawing.Point(864, 175);
            this.Sohranit.Name = "Sohranit";
            this.Sohranit.Size = new System.Drawing.Size(166, 50);
            this.Sohranit.TabIndex = 52;
            this.Sohranit.Text = "Сохранить";
            this.Sohranit.UseVisualStyleBackColor = false;
            // 
            // Ydalit
            // 
            this.Ydalit.BackColor = System.Drawing.Color.Silver;
            this.Ydalit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Ydalit.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Ydalit.Location = new System.Drawing.Point(422, 175);
            this.Ydalit.Name = "Ydalit";
            this.Ydalit.Size = new System.Drawing.Size(184, 50);
            this.Ydalit.TabIndex = 51;
            this.Ydalit.Text = "Удалить";
            this.Ydalit.UseVisualStyleBackColor = false;
            // 
            // Dobavit
            // 
            this.Dobavit.BackColor = System.Drawing.Color.Silver;
            this.Dobavit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Dobavit.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Dobavit.Location = new System.Drawing.Point(216, 175);
            this.Dobavit.Name = "Dobavit";
            this.Dobavit.Size = new System.Drawing.Size(184, 50);
            this.Dobavit.TabIndex = 50;
            this.Dobavit.Text = "Добавить";
            this.Dobavit.UseVisualStyleBackColor = false;
            // 
            // Pervaya
            // 
            this.Pervaya.BackColor = System.Drawing.Color.Silver;
            this.Pervaya.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Pervaya.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Pervaya.Location = new System.Drawing.Point(216, 477);
            this.Pervaya.Name = "Pervaya";
            this.Pervaya.Size = new System.Drawing.Size(184, 50);
            this.Pervaya.TabIndex = 49;
            this.Pervaya.Text = "Первая";
            this.Pervaya.UseVisualStyleBackColor = false;
            // 
            // Zagolovok
            // 
            this.Zagolovok.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Zagolovok.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Zagolovok.ForeColor = System.Drawing.Color.White;
            this.Zagolovok.Location = new System.Drawing.Point(417, 18);
            this.Zagolovok.Name = "Zagolovok";
            this.Zagolovok.Size = new System.Drawing.Size(402, 72);
            this.Zagolovok.TabIndex = 44;
            this.Zagolovok.Text = "Клиенты";
            this.Zagolovok.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Nazad
            // 
            this.Nazad.BackColor = System.Drawing.Color.Silver;
            this.Nazad.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Nazad.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Nazad.Location = new System.Drawing.Point(13, 40);
            this.Nazad.Name = "Nazad";
            this.Nazad.Size = new System.Drawing.Size(250, 50);
            this.Nazad.TabIndex = 42;
            this.Nazad.Text = "Назад";
            this.Nazad.UseVisualStyleBackColor = false;
            this.Nazad.Click += new System.EventHandler(this.Vyhod_Click);
            // 
            // Shapka
            // 
            this.Shapka.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Shapka.Location = new System.Drawing.Point(-3, -6);
            this.Shapka.Name = "Shapka";
            this.Shapka.Size = new System.Drawing.Size(1189, 143);
            this.Shapka.TabIndex = 41;
            this.Shapka.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pictureBox1.Image = global::DE_Bibilov_17.Properties.Resources.free_icon_double_bed_59284341;
            this.pictureBox1.Location = new System.Drawing.Point(1043, 18);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(114, 96);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 43;
            this.pictureBox1.TabStop = false;
            // 
            // dE_Bibilov_17DataSet
            // 
            this.dE_Bibilov_17DataSet.DataSetName = "DE_Bibilov_17DataSet";
            this.dE_Bibilov_17DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // klientyBindingSource
            // 
            this.klientyBindingSource.DataMember = "Klienty";
            this.klientyBindingSource.DataSource = this.dE_Bibilov_17DataSet;
            // 
            // klientyTableAdapter
            // 
            this.klientyTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.AvtorizaciyaTableAdapter = null;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.IzdeliyaTableAdapter = null;
            this.tableAdapterManager.KlientyTableAdapter = this.klientyTableAdapter;
            this.tableAdapterManager.SotrudnikiTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = DE_Bibilov_17.DE_Bibilov_17DataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.ZakazyTableAdapter = null;
            // 
            // codTextBox
            // 
            this.codTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.klientyBindingSource, "Cod", true));
            this.codTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.codTextBox.Location = new System.Drawing.Point(504, 244);
            this.codTextBox.Name = "codTextBox";
            this.codTextBox.Size = new System.Drawing.Size(338, 34);
            this.codTextBox.TabIndex = 57;
            // 
            // fIOTextBox
            // 
            this.fIOTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.klientyBindingSource, "FIO", true));
            this.fIOTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.fIOTextBox.Location = new System.Drawing.Point(504, 303);
            this.fIOTextBox.Name = "fIOTextBox";
            this.fIOTextBox.Size = new System.Drawing.Size(338, 34);
            this.fIOTextBox.TabIndex = 58;
            // 
            // dolzhnostTextBox
            // 
            this.dolzhnostTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.klientyBindingSource, "Dolzhnost", true));
            this.dolzhnostTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dolzhnostTextBox.Location = new System.Drawing.Point(504, 363);
            this.dolzhnostTextBox.Name = "dolzhnostTextBox";
            this.dolzhnostTextBox.Size = new System.Drawing.Size(338, 34);
            this.dolzhnostTextBox.TabIndex = 59;
            // 
            // adresTextBox
            // 
            this.adresTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.klientyBindingSource, "Adres", true));
            this.adresTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.adresTextBox.Location = new System.Drawing.Point(504, 422);
            this.adresTextBox.Name = "adresTextBox";
            this.adresTextBox.Size = new System.Drawing.Size(338, 34);
            this.adresTextBox.TabIndex = 60;
            // 
            // Klienty
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1182, 553);
            this.Controls.Add(this.adresTextBox);
            this.Controls.Add(this.dolzhnostTextBox);
            this.Controls.Add(this.fIOTextBox);
            this.Controls.Add(this.codTextBox);
            this.Controls.Add(this.Posledniya);
            this.Controls.Add(this.Sledyushaya);
            this.Controls.Add(this.Predydushaya);
            this.Controls.Add(this.Sohranit);
            this.Controls.Add(this.Ydalit);
            this.Controls.Add(this.Dobavit);
            this.Controls.Add(this.Pervaya);
            this.Controls.Add(osnovnoi_materialLabel);
            this.Controls.Add(stoimostLabel);
            this.Controls.Add(vid_izdeliyaLabel);
            this.Controls.Add(codLabel);
            this.Controls.Add(this.Zagolovok);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.Nazad);
            this.Controls.Add(this.Shapka);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Klienty";
            this.Text = "Клиенты";
            this.Load += new System.EventHandler(this.Klienty_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dE_Bibilov_17DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.klientyBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button Posledniya;
        private System.Windows.Forms.Button Sledyushaya;
        private System.Windows.Forms.Button Predydushaya;
        private System.Windows.Forms.Button Sohranit;
        private System.Windows.Forms.Button Ydalit;
        private System.Windows.Forms.Button Dobavit;
        private System.Windows.Forms.Button Pervaya;
        private System.Windows.Forms.Label Zagolovok;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button Nazad;
        private System.Windows.Forms.Label Shapka;
        private DE_Bibilov_17DataSet dE_Bibilov_17DataSet;
        private System.Windows.Forms.BindingSource klientyBindingSource;
        private DE_Bibilov_17DataSetTableAdapters.KlientyTableAdapter klientyTableAdapter;
        private DE_Bibilov_17DataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.TextBox codTextBox;
        private System.Windows.Forms.TextBox fIOTextBox;
        private System.Windows.Forms.TextBox dolzhnostTextBox;
        private System.Windows.Forms.TextBox adresTextBox;
    }
}