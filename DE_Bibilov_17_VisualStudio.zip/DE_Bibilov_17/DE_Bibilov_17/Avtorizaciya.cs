﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DE_Bibilov_17
{
    public partial class Avtorizaciya : Form
    {
        public Avtorizaciya()
        {
            InitializeComponent();
        }

        private void Voyti_Click(object sender, EventArgs e)
        {
            SqlConnection sqlcon = new SqlConnection(@"Data Source=DESKTOP-5OGH5AD\SQLEXPRESS;Initial Catalog=DE_Bibilov_17;Integrated Security=True");
            string query = "Select * from [Avtorizaciya] Where Login= '" + Login.Text.Trim() + "' and Password = '" + Password.Text.Trim() + "'";
            SqlDataAdapter sda = new SqlDataAdapter(query, sqlcon);
            DataTable dtbi = new DataTable();
            sda.Fill(dtbi);
            if (dtbi.Rows.Count == 1)
            {
                if (Login.Text == "Admin")
                {
                    Menu_admin frm = new Menu_admin();
                    frm.Show();
                    this.Hide();
                    MessageBox.Show("Добро пожаловать");
                }
                else
                {
                    Menu frm = new Menu();
                    frm.Show();
                    this.Hide();
                    MessageBox.Show("Добро пожаловать");
                }
            }
        }

        private void Nazad_Click(object sender, EventArgs e)
        {
            Menu fm = new Menu();
            fm.Show();
            this.Hide();
        }
    }
}

        