﻿
namespace DE_Bibilov_17
{
    partial class Izdeliya_Admin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label osnovnoi_materialLabel;
            System.Windows.Forms.Label stoimostLabel;
            System.Windows.Forms.Label vid_izdeliyaLabel;
            System.Windows.Forms.Label codLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Izdeliya_Admin));
            this.Posledniya = new System.Windows.Forms.Button();
            this.Sledyushaya = new System.Windows.Forms.Button();
            this.Predydushaya = new System.Windows.Forms.Button();
            this.Sohranit = new System.Windows.Forms.Button();
            this.Ydalit = new System.Windows.Forms.Button();
            this.Dobavit = new System.Windows.Forms.Button();
            this.Pervaya = new System.Windows.Forms.Button();
            this.Zagolovok = new System.Windows.Forms.Label();
            this.Nazad = new System.Windows.Forms.Button();
            this.Shapka = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.dE_Bibilov_17DataSet = new DE_Bibilov_17.DE_Bibilov_17DataSet();
            this.izdeliyaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.izdeliyaTableAdapter = new DE_Bibilov_17.DE_Bibilov_17DataSetTableAdapters.IzdeliyaTableAdapter();
            this.tableAdapterManager = new DE_Bibilov_17.DE_Bibilov_17DataSetTableAdapters.TableAdapterManager();
            this.codTextBox1 = new System.Windows.Forms.TextBox();
            this.vid_izdeliyaTextBox1 = new System.Windows.Forms.TextBox();
            this.stoimostTextBox1 = new System.Windows.Forms.TextBox();
            this.osnovnoi_materialTextBox1 = new System.Windows.Forms.TextBox();
            osnovnoi_materialLabel = new System.Windows.Forms.Label();
            stoimostLabel = new System.Windows.Forms.Label();
            vid_izdeliyaLabel = new System.Windows.Forms.Label();
            codLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dE_Bibilov_17DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.izdeliyaBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // osnovnoi_materialLabel
            // 
            osnovnoi_materialLabel.BackColor = System.Drawing.Color.Transparent;
            osnovnoi_materialLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            osnovnoi_materialLabel.Location = new System.Drawing.Point(339, 425);
            osnovnoi_materialLabel.Name = "osnovnoi_materialLabel";
            osnovnoi_materialLabel.Size = new System.Drawing.Size(162, 34);
            osnovnoi_materialLabel.TabIndex = 30;
            osnovnoi_materialLabel.Text = "Материал:";
            osnovnoi_materialLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // stoimostLabel
            // 
            stoimostLabel.BackColor = System.Drawing.Color.Transparent;
            stoimostLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            stoimostLabel.Location = new System.Drawing.Point(334, 366);
            stoimostLabel.Name = "stoimostLabel";
            stoimostLabel.Size = new System.Drawing.Size(167, 34);
            stoimostLabel.TabIndex = 29;
            stoimostLabel.Text = "Стоимость:";
            stoimostLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // vid_izdeliyaLabel
            // 
            vid_izdeliyaLabel.BackColor = System.Drawing.Color.Transparent;
            vid_izdeliyaLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            vid_izdeliyaLabel.Location = new System.Drawing.Point(263, 306);
            vid_izdeliyaLabel.Name = "vid_izdeliyaLabel";
            vid_izdeliyaLabel.Size = new System.Drawing.Size(238, 34);
            vid_izdeliyaLabel.TabIndex = 27;
            vid_izdeliyaLabel.Text = "Вид изделия:";
            vid_izdeliyaLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // codLabel
            // 
            codLabel.BackColor = System.Drawing.Color.Transparent;
            codLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            codLabel.Location = new System.Drawing.Point(334, 247);
            codLabel.Name = "codLabel";
            codLabel.Size = new System.Drawing.Size(167, 34);
            codLabel.TabIndex = 25;
            codLabel.Text = "Код:";
            codLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Posledniya
            // 
            this.Posledniya.BackColor = System.Drawing.Color.Silver;
            this.Posledniya.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Posledniya.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Posledniya.Location = new System.Drawing.Point(867, 480);
            this.Posledniya.Name = "Posledniya";
            this.Posledniya.Size = new System.Drawing.Size(166, 50);
            this.Posledniya.TabIndex = 39;
            this.Posledniya.Text = "Последняя";
            this.Posledniya.UseVisualStyleBackColor = false;
            // 
            // Sledyushaya
            // 
            this.Sledyushaya.BackColor = System.Drawing.Color.Silver;
            this.Sledyushaya.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Sledyushaya.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Sledyushaya.Location = new System.Drawing.Point(638, 480);
            this.Sledyushaya.Name = "Sledyushaya";
            this.Sledyushaya.Size = new System.Drawing.Size(195, 50);
            this.Sledyushaya.TabIndex = 38;
            this.Sledyushaya.Text = "Следующая";
            this.Sledyushaya.UseVisualStyleBackColor = false;
            // 
            // Predydushaya
            // 
            this.Predydushaya.BackColor = System.Drawing.Color.Silver;
            this.Predydushaya.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Predydushaya.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Predydushaya.Location = new System.Drawing.Point(436, 480);
            this.Predydushaya.Name = "Predydushaya";
            this.Predydushaya.Size = new System.Drawing.Size(195, 50);
            this.Predydushaya.TabIndex = 37;
            this.Predydushaya.Text = "Предыдущая";
            this.Predydushaya.UseVisualStyleBackColor = false;
            // 
            // Sohranit
            // 
            this.Sohranit.BackColor = System.Drawing.Color.Silver;
            this.Sohranit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Sohranit.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Sohranit.Location = new System.Drawing.Point(867, 178);
            this.Sohranit.Name = "Sohranit";
            this.Sohranit.Size = new System.Drawing.Size(166, 50);
            this.Sohranit.TabIndex = 36;
            this.Sohranit.Text = "Сохранить";
            this.Sohranit.UseVisualStyleBackColor = false;
            // 
            // Ydalit
            // 
            this.Ydalit.BackColor = System.Drawing.Color.Silver;
            this.Ydalit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Ydalit.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Ydalit.Location = new System.Drawing.Point(425, 178);
            this.Ydalit.Name = "Ydalit";
            this.Ydalit.Size = new System.Drawing.Size(184, 50);
            this.Ydalit.TabIndex = 35;
            this.Ydalit.Text = "Удалить";
            this.Ydalit.UseVisualStyleBackColor = false;
            // 
            // Dobavit
            // 
            this.Dobavit.BackColor = System.Drawing.Color.Silver;
            this.Dobavit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Dobavit.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Dobavit.Location = new System.Drawing.Point(219, 178);
            this.Dobavit.Name = "Dobavit";
            this.Dobavit.Size = new System.Drawing.Size(184, 50);
            this.Dobavit.TabIndex = 34;
            this.Dobavit.Text = "Добавить";
            this.Dobavit.UseVisualStyleBackColor = false;
            // 
            // Pervaya
            // 
            this.Pervaya.BackColor = System.Drawing.Color.Silver;
            this.Pervaya.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Pervaya.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Pervaya.Location = new System.Drawing.Point(219, 480);
            this.Pervaya.Name = "Pervaya";
            this.Pervaya.Size = new System.Drawing.Size(184, 50);
            this.Pervaya.TabIndex = 33;
            this.Pervaya.Text = "Первая";
            this.Pervaya.UseVisualStyleBackColor = false;
            // 
            // Zagolovok
            // 
            this.Zagolovok.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Zagolovok.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Zagolovok.ForeColor = System.Drawing.Color.White;
            this.Zagolovok.Location = new System.Drawing.Point(417, 22);
            this.Zagolovok.Name = "Zagolovok";
            this.Zagolovok.Size = new System.Drawing.Size(402, 72);
            this.Zagolovok.TabIndex = 24;
            this.Zagolovok.Text = "Изделия";
            this.Zagolovok.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Nazad
            // 
            this.Nazad.BackColor = System.Drawing.Color.Silver;
            this.Nazad.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Nazad.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Nazad.Location = new System.Drawing.Point(13, 44);
            this.Nazad.Name = "Nazad";
            this.Nazad.Size = new System.Drawing.Size(250, 50);
            this.Nazad.TabIndex = 22;
            this.Nazad.Text = "Назад";
            this.Nazad.UseVisualStyleBackColor = false;
            this.Nazad.Click += new System.EventHandler(this.Nazad_Click);
            // 
            // Shapka
            // 
            this.Shapka.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Shapka.Location = new System.Drawing.Point(-3, -2);
            this.Shapka.Name = "Shapka";
            this.Shapka.Size = new System.Drawing.Size(1189, 143);
            this.Shapka.TabIndex = 21;
            this.Shapka.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pictureBox1.Image = global::DE_Bibilov_17.Properties.Resources.free_icon_double_bed_59284341;
            this.pictureBox1.Location = new System.Drawing.Point(1043, 22);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(114, 96);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 23;
            this.pictureBox1.TabStop = false;
            // 
            // dE_Bibilov_17DataSet
            // 
            this.dE_Bibilov_17DataSet.DataSetName = "DE_Bibilov_17DataSet";
            this.dE_Bibilov_17DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // izdeliyaBindingSource
            // 
            this.izdeliyaBindingSource.DataMember = "Izdeliya";
            this.izdeliyaBindingSource.DataSource = this.dE_Bibilov_17DataSet;
            // 
            // izdeliyaTableAdapter
            // 
            this.izdeliyaTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.AvtorizaciyaTableAdapter = null;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.IzdeliyaTableAdapter = this.izdeliyaTableAdapter;
            this.tableAdapterManager.KlientyTableAdapter = null;
            this.tableAdapterManager.SotrudnikiTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = DE_Bibilov_17.DE_Bibilov_17DataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.ZakazyTableAdapter = null;
            // 
            // codTextBox1
            // 
            this.codTextBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.izdeliyaBindingSource, "Cod", true));
            this.codTextBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.codTextBox1.Location = new System.Drawing.Point(507, 247);
            this.codTextBox1.Name = "codTextBox1";
            this.codTextBox1.Size = new System.Drawing.Size(338, 34);
            this.codTextBox1.TabIndex = 41;
            // 
            // vid_izdeliyaTextBox1
            // 
            this.vid_izdeliyaTextBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.izdeliyaBindingSource, "Vid_izdeliya", true));
            this.vid_izdeliyaTextBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.vid_izdeliyaTextBox1.Location = new System.Drawing.Point(507, 306);
            this.vid_izdeliyaTextBox1.Name = "vid_izdeliyaTextBox1";
            this.vid_izdeliyaTextBox1.Size = new System.Drawing.Size(338, 34);
            this.vid_izdeliyaTextBox1.TabIndex = 42;
            // 
            // stoimostTextBox1
            // 
            this.stoimostTextBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.izdeliyaBindingSource, "Stoimost", true));
            this.stoimostTextBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.stoimostTextBox1.Location = new System.Drawing.Point(507, 366);
            this.stoimostTextBox1.Name = "stoimostTextBox1";
            this.stoimostTextBox1.Size = new System.Drawing.Size(338, 34);
            this.stoimostTextBox1.TabIndex = 43;
            // 
            // osnovnoi_materialTextBox1
            // 
            this.osnovnoi_materialTextBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.izdeliyaBindingSource, "Osnovnoi_material", true));
            this.osnovnoi_materialTextBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.osnovnoi_materialTextBox1.Location = new System.Drawing.Point(507, 425);
            this.osnovnoi_materialTextBox1.Name = "osnovnoi_materialTextBox1";
            this.osnovnoi_materialTextBox1.Size = new System.Drawing.Size(338, 34);
            this.osnovnoi_materialTextBox1.TabIndex = 44;
            // 
            // Izdeliya_Admin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1182, 553);
            this.Controls.Add(this.osnovnoi_materialTextBox1);
            this.Controls.Add(this.stoimostTextBox1);
            this.Controls.Add(this.vid_izdeliyaTextBox1);
            this.Controls.Add(this.codTextBox1);
            this.Controls.Add(this.Posledniya);
            this.Controls.Add(this.Sledyushaya);
            this.Controls.Add(this.Predydushaya);
            this.Controls.Add(this.Sohranit);
            this.Controls.Add(this.Ydalit);
            this.Controls.Add(this.Dobavit);
            this.Controls.Add(this.Pervaya);
            this.Controls.Add(osnovnoi_materialLabel);
            this.Controls.Add(stoimostLabel);
            this.Controls.Add(vid_izdeliyaLabel);
            this.Controls.Add(codLabel);
            this.Controls.Add(this.Zagolovok);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.Nazad);
            this.Controls.Add(this.Shapka);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Izdeliya_Admin";
            this.Text = "Изделия";
            this.Load += new System.EventHandler(this.Izdeliya_Admin_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dE_Bibilov_17DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.izdeliyaBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Posledniya;
        private System.Windows.Forms.Button Sledyushaya;
        private System.Windows.Forms.Button Predydushaya;
        private System.Windows.Forms.Button Sohranit;
        private System.Windows.Forms.Button Ydalit;
        private System.Windows.Forms.Button Dobavit;
        private System.Windows.Forms.Button Pervaya;
        private System.Windows.Forms.Label Zagolovok;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button Nazad;
        private System.Windows.Forms.Label Shapka;
        private DE_Bibilov_17DataSet dE_Bibilov_17DataSet;
        private System.Windows.Forms.BindingSource izdeliyaBindingSource;
        private DE_Bibilov_17DataSetTableAdapters.IzdeliyaTableAdapter izdeliyaTableAdapter;
        private DE_Bibilov_17DataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.TextBox codTextBox1;
        private System.Windows.Forms.TextBox vid_izdeliyaTextBox1;
        private System.Windows.Forms.TextBox stoimostTextBox1;
        private System.Windows.Forms.TextBox osnovnoi_materialTextBox1;
    }
}