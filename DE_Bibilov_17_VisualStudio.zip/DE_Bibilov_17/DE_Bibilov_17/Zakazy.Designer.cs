﻿
namespace DE_Bibilov_17
{
    partial class Zakazy
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label osnovnoi_materialLabel;
            System.Windows.Forms.Label stoimostLabel;
            System.Windows.Forms.Label vid_izdeliyaLabel;
            System.Windows.Forms.Label codLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Zakazy));
            this.Zagolovok = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Nazad = new System.Windows.Forms.Button();
            this.Shapka = new System.Windows.Forms.Label();
            this.Posledniya = new System.Windows.Forms.Button();
            this.Sledyushaya = new System.Windows.Forms.Button();
            this.Predydushaya = new System.Windows.Forms.Button();
            this.Sohranit = new System.Windows.Forms.Button();
            this.Ydalit = new System.Windows.Forms.Button();
            this.Dobavit = new System.Windows.Forms.Button();
            this.Pervaya = new System.Windows.Forms.Button();
            this.dE_Bibilov_17DataSet = new DE_Bibilov_17.DE_Bibilov_17DataSet();
            this.zakazyBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.zakazyTableAdapter = new DE_Bibilov_17.DE_Bibilov_17DataSetTableAdapters.ZakazyTableAdapter();
            this.tableAdapterManager = new DE_Bibilov_17.DE_Bibilov_17DataSetTableAdapters.TableAdapterManager();
            this.codTextBox = new System.Windows.Forms.TextBox();
            this.nomer_zakazaTextBox = new System.Windows.Forms.TextBox();
            this.fIOTextBox = new System.Windows.Forms.TextBox();
            this.nomer_telefonaTextBox = new System.Windows.Forms.TextBox();
            osnovnoi_materialLabel = new System.Windows.Forms.Label();
            stoimostLabel = new System.Windows.Forms.Label();
            vid_izdeliyaLabel = new System.Windows.Forms.Label();
            codLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dE_Bibilov_17DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zakazyBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // osnovnoi_materialLabel
            // 
            osnovnoi_materialLabel.BackColor = System.Drawing.Color.Transparent;
            osnovnoi_materialLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            osnovnoi_materialLabel.Location = new System.Drawing.Point(242, 427);
            osnovnoi_materialLabel.Name = "osnovnoi_materialLabel";
            osnovnoi_materialLabel.Size = new System.Drawing.Size(256, 34);
            osnovnoi_materialLabel.TabIndex = 26;
            osnovnoi_materialLabel.Text = "Номер телефона:";
            osnovnoi_materialLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // stoimostLabel
            // 
            stoimostLabel.BackColor = System.Drawing.Color.Transparent;
            stoimostLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            stoimostLabel.Location = new System.Drawing.Point(331, 368);
            stoimostLabel.Name = "stoimostLabel";
            stoimostLabel.Size = new System.Drawing.Size(167, 34);
            stoimostLabel.TabIndex = 24;
            stoimostLabel.Text = "ФИО:";
            stoimostLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // vid_izdeliyaLabel
            // 
            vid_izdeliyaLabel.BackColor = System.Drawing.Color.Transparent;
            vid_izdeliyaLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            vid_izdeliyaLabel.Location = new System.Drawing.Point(260, 308);
            vid_izdeliyaLabel.Name = "vid_izdeliyaLabel";
            vid_izdeliyaLabel.Size = new System.Drawing.Size(238, 34);
            vid_izdeliyaLabel.TabIndex = 22;
            vid_izdeliyaLabel.Text = "Номер заказа:";
            vid_izdeliyaLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // codLabel
            // 
            codLabel.BackColor = System.Drawing.Color.Transparent;
            codLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            codLabel.Location = new System.Drawing.Point(331, 249);
            codLabel.Name = "codLabel";
            codLabel.Size = new System.Drawing.Size(167, 34);
            codLabel.TabIndex = 21;
            codLabel.Text = "Код:";
            codLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Zagolovok
            // 
            this.Zagolovok.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Zagolovok.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Zagolovok.ForeColor = System.Drawing.Color.White;
            this.Zagolovok.Location = new System.Drawing.Point(417, 23);
            this.Zagolovok.Name = "Zagolovok";
            this.Zagolovok.Size = new System.Drawing.Size(402, 72);
            this.Zagolovok.TabIndex = 13;
            this.Zagolovok.Text = "Заказы";
            this.Zagolovok.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pictureBox1.Image = global::DE_Bibilov_17.Properties.Resources.free_icon_double_bed_59284341;
            this.pictureBox1.Location = new System.Drawing.Point(1043, 23);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(114, 96);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 12;
            this.pictureBox1.TabStop = false;
            // 
            // Nazad
            // 
            this.Nazad.BackColor = System.Drawing.Color.Silver;
            this.Nazad.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Nazad.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Nazad.Location = new System.Drawing.Point(13, 45);
            this.Nazad.Name = "Nazad";
            this.Nazad.Size = new System.Drawing.Size(250, 50);
            this.Nazad.TabIndex = 11;
            this.Nazad.Text = "Назад";
            this.Nazad.UseVisualStyleBackColor = false;
            this.Nazad.Click += new System.EventHandler(this.Vyhod_Click);
            // 
            // Shapka
            // 
            this.Shapka.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Shapka.Location = new System.Drawing.Point(-3, -1);
            this.Shapka.Name = "Shapka";
            this.Shapka.Size = new System.Drawing.Size(1189, 143);
            this.Shapka.TabIndex = 10;
            this.Shapka.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Posledniya
            // 
            this.Posledniya.BackColor = System.Drawing.Color.Silver;
            this.Posledniya.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Posledniya.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Posledniya.Location = new System.Drawing.Point(864, 482);
            this.Posledniya.Name = "Posledniya";
            this.Posledniya.Size = new System.Drawing.Size(166, 50);
            this.Posledniya.TabIndex = 35;
            this.Posledniya.Text = "Последняя";
            this.Posledniya.UseVisualStyleBackColor = false;
            // 
            // Sledyushaya
            // 
            this.Sledyushaya.BackColor = System.Drawing.Color.Silver;
            this.Sledyushaya.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Sledyushaya.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Sledyushaya.Location = new System.Drawing.Point(635, 482);
            this.Sledyushaya.Name = "Sledyushaya";
            this.Sledyushaya.Size = new System.Drawing.Size(195, 50);
            this.Sledyushaya.TabIndex = 34;
            this.Sledyushaya.Text = "Следующая";
            this.Sledyushaya.UseVisualStyleBackColor = false;
            // 
            // Predydushaya
            // 
            this.Predydushaya.BackColor = System.Drawing.Color.Silver;
            this.Predydushaya.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Predydushaya.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Predydushaya.Location = new System.Drawing.Point(433, 482);
            this.Predydushaya.Name = "Predydushaya";
            this.Predydushaya.Size = new System.Drawing.Size(195, 50);
            this.Predydushaya.TabIndex = 33;
            this.Predydushaya.Text = "Предыдущая";
            this.Predydushaya.UseVisualStyleBackColor = false;
            // 
            // Sohranit
            // 
            this.Sohranit.BackColor = System.Drawing.Color.Silver;
            this.Sohranit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Sohranit.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Sohranit.Location = new System.Drawing.Point(864, 180);
            this.Sohranit.Name = "Sohranit";
            this.Sohranit.Size = new System.Drawing.Size(166, 50);
            this.Sohranit.TabIndex = 32;
            this.Sohranit.Text = "Сохранить";
            this.Sohranit.UseVisualStyleBackColor = false;
            // 
            // Ydalit
            // 
            this.Ydalit.BackColor = System.Drawing.Color.Silver;
            this.Ydalit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Ydalit.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Ydalit.Location = new System.Drawing.Point(422, 180);
            this.Ydalit.Name = "Ydalit";
            this.Ydalit.Size = new System.Drawing.Size(184, 50);
            this.Ydalit.TabIndex = 31;
            this.Ydalit.Text = "Удалить";
            this.Ydalit.UseVisualStyleBackColor = false;
            // 
            // Dobavit
            // 
            this.Dobavit.BackColor = System.Drawing.Color.Silver;
            this.Dobavit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Dobavit.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Dobavit.Location = new System.Drawing.Point(216, 180);
            this.Dobavit.Name = "Dobavit";
            this.Dobavit.Size = new System.Drawing.Size(184, 50);
            this.Dobavit.TabIndex = 30;
            this.Dobavit.Text = "Добавить";
            this.Dobavit.UseVisualStyleBackColor = false;
            // 
            // Pervaya
            // 
            this.Pervaya.BackColor = System.Drawing.Color.Silver;
            this.Pervaya.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Pervaya.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Pervaya.Location = new System.Drawing.Point(216, 482);
            this.Pervaya.Name = "Pervaya";
            this.Pervaya.Size = new System.Drawing.Size(184, 50);
            this.Pervaya.TabIndex = 29;
            this.Pervaya.Text = "Первая";
            this.Pervaya.UseVisualStyleBackColor = false;
            // 
            // dE_Bibilov_17DataSet
            // 
            this.dE_Bibilov_17DataSet.DataSetName = "DE_Bibilov_17DataSet";
            this.dE_Bibilov_17DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // zakazyBindingSource
            // 
            this.zakazyBindingSource.DataMember = "Zakazy";
            this.zakazyBindingSource.DataSource = this.dE_Bibilov_17DataSet;
            // 
            // zakazyTableAdapter
            // 
            this.zakazyTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.AvtorizaciyaTableAdapter = null;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.IzdeliyaTableAdapter = null;
            this.tableAdapterManager.KlientyTableAdapter = null;
            this.tableAdapterManager.SotrudnikiTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = DE_Bibilov_17.DE_Bibilov_17DataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.ZakazyTableAdapter = this.zakazyTableAdapter;
            // 
            // codTextBox
            // 
            this.codTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.zakazyBindingSource, "Cod", true));
            this.codTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.codTextBox.Location = new System.Drawing.Point(504, 249);
            this.codTextBox.Name = "codTextBox";
            this.codTextBox.Size = new System.Drawing.Size(338, 34);
            this.codTextBox.TabIndex = 37;
            // 
            // nomer_zakazaTextBox
            // 
            this.nomer_zakazaTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.zakazyBindingSource, "Nomer_zakaza", true));
            this.nomer_zakazaTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.nomer_zakazaTextBox.Location = new System.Drawing.Point(504, 308);
            this.nomer_zakazaTextBox.Name = "nomer_zakazaTextBox";
            this.nomer_zakazaTextBox.Size = new System.Drawing.Size(338, 34);
            this.nomer_zakazaTextBox.TabIndex = 38;
            // 
            // fIOTextBox
            // 
            this.fIOTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.zakazyBindingSource, "FIO", true));
            this.fIOTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.fIOTextBox.Location = new System.Drawing.Point(504, 368);
            this.fIOTextBox.Name = "fIOTextBox";
            this.fIOTextBox.Size = new System.Drawing.Size(338, 34);
            this.fIOTextBox.TabIndex = 39;
            // 
            // nomer_telefonaTextBox
            // 
            this.nomer_telefonaTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.zakazyBindingSource, "Nomer_telefona", true));
            this.nomer_telefonaTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.nomer_telefonaTextBox.Location = new System.Drawing.Point(504, 427);
            this.nomer_telefonaTextBox.Name = "nomer_telefonaTextBox";
            this.nomer_telefonaTextBox.Size = new System.Drawing.Size(338, 34);
            this.nomer_telefonaTextBox.TabIndex = 40;
            // 
            // Zakazy
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1182, 553);
            this.Controls.Add(this.nomer_telefonaTextBox);
            this.Controls.Add(this.fIOTextBox);
            this.Controls.Add(this.nomer_zakazaTextBox);
            this.Controls.Add(this.codTextBox);
            this.Controls.Add(this.Posledniya);
            this.Controls.Add(this.Sledyushaya);
            this.Controls.Add(this.Predydushaya);
            this.Controls.Add(this.Sohranit);
            this.Controls.Add(this.Ydalit);
            this.Controls.Add(this.Dobavit);
            this.Controls.Add(this.Pervaya);
            this.Controls.Add(osnovnoi_materialLabel);
            this.Controls.Add(stoimostLabel);
            this.Controls.Add(vid_izdeliyaLabel);
            this.Controls.Add(codLabel);
            this.Controls.Add(this.Zagolovok);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.Nazad);
            this.Controls.Add(this.Shapka);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Zakazy";
            this.Text = "Заказы";
            this.Load += new System.EventHandler(this.Zakazy_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dE_Bibilov_17DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zakazyBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Zagolovok;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button Nazad;
        private System.Windows.Forms.Label Shapka;
        private System.Windows.Forms.Button Posledniya;
        private System.Windows.Forms.Button Sledyushaya;
        private System.Windows.Forms.Button Predydushaya;
        private System.Windows.Forms.Button Sohranit;
        private System.Windows.Forms.Button Ydalit;
        private System.Windows.Forms.Button Dobavit;
        private System.Windows.Forms.Button Pervaya;
        private DE_Bibilov_17DataSet dE_Bibilov_17DataSet;
        private System.Windows.Forms.BindingSource zakazyBindingSource;
        private DE_Bibilov_17DataSetTableAdapters.ZakazyTableAdapter zakazyTableAdapter;
        private DE_Bibilov_17DataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.TextBox codTextBox;
        private System.Windows.Forms.TextBox nomer_zakazaTextBox;
        private System.Windows.Forms.TextBox fIOTextBox;
        private System.Windows.Forms.TextBox nomer_telefonaTextBox;
    }
}