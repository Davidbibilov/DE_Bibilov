﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DE_Bibilov_17
{
    public partial class Izdeliya_Admin : Form
    {
        public Izdeliya_Admin()
        {
            InitializeComponent();
        }

        private void izdeliyaBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.izdeliyaBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.dE_Bibilov_17DataSet);

        }

        private void Izdeliya_Admin_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "dE_Bibilov_17DataSet.Izdeliya". При необходимости она может быть перемещена или удалена.
            this.izdeliyaTableAdapter.Fill(this.dE_Bibilov_17DataSet.Izdeliya);

        }

        private void Nazad_Click(object sender, EventArgs e)
        {
            Menu_admin fm = new Menu_admin();
            fm.Show();
            this.Hide();
        }
    }
}
