﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DE_Bibilov_17
{
    public partial class Izdeliya : Form
    {
        public Izdeliya()
        {
            InitializeComponent();
        }

        private void izdeliyaBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.izdeliyaBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.dE_Bibilov_17DataSet);

        }

        private void Izdeliya_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "dE_Bibilov_17DataSet.Izdeliya". При необходимости она может быть перемещена или удалена.
            this.izdeliyaTableAdapter.Fill(this.dE_Bibilov_17DataSet.Izdeliya);

        }

        private void Nazad_Click(object sender, EventArgs e)
        {
            Menu fm = new Menu();
            fm.Show();
            this.Hide();
        }

        private void Poisk_Click(object sender, EventArgs e)
        {

        }
    }
}
