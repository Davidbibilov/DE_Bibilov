﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DE_Bibilov_17
{
    public partial class Menu_admin : Form
    {
        public Menu_admin()
        {
            InitializeComponent();
        }

        private void Vyhod_Click(object sender, EventArgs e)
        {
            Menu fm = new Menu();
            fm.Show();
            this.Hide();
        }

        private void Izdeliya_Click(object sender, EventArgs e)
        {
            Izdeliya_Admin fm = new Izdeliya_Admin();
            fm.Show();
            this.Hide();
        }

        private void Zakazy_Click(object sender, EventArgs e)
        {
            Zakazy fm = new Zakazy();
            fm.Show();
            this.Hide();
        }

        private void Klienty_Click(object sender, EventArgs e)
        {
            Klienty fm = new Klienty();
            fm.Show();
            this.Hide();
        }

        private void Sotrudniki_Click(object sender, EventArgs e)
        {
            Sotrudniki_Admin fm = new Sotrudniki_Admin();
            fm.Show();
            this.Hide();
        }
    }
}
