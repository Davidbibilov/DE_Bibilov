﻿
namespace DE_Bibilov_17
{
    partial class Izdeliya
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Izdeliya));
            this.Zagolovok = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Nazad = new System.Windows.Forms.Button();
            this.Shapka = new System.Windows.Forms.Label();
            this.dE_Bibilov_17DataSet = new DE_Bibilov_17.DE_Bibilov_17DataSet();
            this.izdeliyaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.izdeliyaTableAdapter = new DE_Bibilov_17.DE_Bibilov_17DataSetTableAdapters.IzdeliyaTableAdapter();
            this.tableAdapterManager = new DE_Bibilov_17.DE_Bibilov_17DataSetTableAdapters.TableAdapterManager();
            this.Pervaya = new System.Windows.Forms.Button();
            this.Dobavit = new System.Windows.Forms.Button();
            this.Ydalit = new System.Windows.Forms.Button();
            this.Sohranit = new System.Windows.Forms.Button();
            this.Predydushaya = new System.Windows.Forms.Button();
            this.Sledyushaya = new System.Windows.Forms.Button();
            this.Posledniya = new System.Windows.Forms.Button();
            this.PoiskBox = new System.Windows.Forms.TextBox();
            this.izdeliyaDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Poisk = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dE_Bibilov_17DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.izdeliyaBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.izdeliyaDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // Zagolovok
            // 
            this.Zagolovok.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Zagolovok.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Zagolovok.ForeColor = System.Drawing.Color.White;
            this.Zagolovok.Location = new System.Drawing.Point(415, 24);
            this.Zagolovok.Name = "Zagolovok";
            this.Zagolovok.Size = new System.Drawing.Size(402, 72);
            this.Zagolovok.TabIndex = 8;
            this.Zagolovok.Text = "Изделия";
            this.Zagolovok.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pictureBox1.Image = global::DE_Bibilov_17.Properties.Resources.free_icon_double_bed_59284341;
            this.pictureBox1.Location = new System.Drawing.Point(1041, 24);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(114, 96);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // Nazad
            // 
            this.Nazad.BackColor = System.Drawing.Color.Silver;
            this.Nazad.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Nazad.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Nazad.Location = new System.Drawing.Point(11, 46);
            this.Nazad.Name = "Nazad";
            this.Nazad.Size = new System.Drawing.Size(250, 50);
            this.Nazad.TabIndex = 6;
            this.Nazad.Text = "Назад";
            this.Nazad.UseVisualStyleBackColor = false;
            this.Nazad.Click += new System.EventHandler(this.Nazad_Click);
            // 
            // Shapka
            // 
            this.Shapka.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Shapka.Location = new System.Drawing.Point(-5, 0);
            this.Shapka.Name = "Shapka";
            this.Shapka.Size = new System.Drawing.Size(1189, 143);
            this.Shapka.TabIndex = 5;
            this.Shapka.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dE_Bibilov_17DataSet
            // 
            this.dE_Bibilov_17DataSet.DataSetName = "DE_Bibilov_17DataSet";
            this.dE_Bibilov_17DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // izdeliyaBindingSource
            // 
            this.izdeliyaBindingSource.DataMember = "Izdeliya";
            this.izdeliyaBindingSource.DataSource = this.dE_Bibilov_17DataSet;
            // 
            // izdeliyaTableAdapter
            // 
            this.izdeliyaTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.AvtorizaciyaTableAdapter = null;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.IzdeliyaTableAdapter = this.izdeliyaTableAdapter;
            this.tableAdapterManager.KlientyTableAdapter = null;
            this.tableAdapterManager.SotrudnikiTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = DE_Bibilov_17.DE_Bibilov_17DataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.ZakazyTableAdapter = null;
            // 
            // Pervaya
            // 
            this.Pervaya.BackColor = System.Drawing.Color.Silver;
            this.Pervaya.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Pervaya.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Pervaya.Location = new System.Drawing.Point(179, 643);
            this.Pervaya.Name = "Pervaya";
            this.Pervaya.Size = new System.Drawing.Size(184, 50);
            this.Pervaya.TabIndex = 14;
            this.Pervaya.Text = "Первая";
            this.Pervaya.UseVisualStyleBackColor = false;
            // 
            // Dobavit
            // 
            this.Dobavit.BackColor = System.Drawing.Color.Silver;
            this.Dobavit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Dobavit.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Dobavit.Location = new System.Drawing.Point(179, 286);
            this.Dobavit.Name = "Dobavit";
            this.Dobavit.Size = new System.Drawing.Size(184, 50);
            this.Dobavit.TabIndex = 15;
            this.Dobavit.Text = "Добавить";
            this.Dobavit.UseVisualStyleBackColor = false;
            // 
            // Ydalit
            // 
            this.Ydalit.BackColor = System.Drawing.Color.Silver;
            this.Ydalit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Ydalit.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Ydalit.Location = new System.Drawing.Point(380, 286);
            this.Ydalit.Name = "Ydalit";
            this.Ydalit.Size = new System.Drawing.Size(184, 50);
            this.Ydalit.TabIndex = 16;
            this.Ydalit.Text = "Удалить";
            this.Ydalit.UseVisualStyleBackColor = false;
            // 
            // Sohranit
            // 
            this.Sohranit.BackColor = System.Drawing.Color.Silver;
            this.Sohranit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Sohranit.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Sohranit.Location = new System.Drawing.Point(796, 286);
            this.Sohranit.Name = "Sohranit";
            this.Sohranit.Size = new System.Drawing.Size(166, 50);
            this.Sohranit.TabIndex = 17;
            this.Sohranit.Text = "Сохранить";
            this.Sohranit.UseVisualStyleBackColor = false;
            // 
            // Predydushaya
            // 
            this.Predydushaya.BackColor = System.Drawing.Color.Silver;
            this.Predydushaya.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Predydushaya.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Predydushaya.Location = new System.Drawing.Point(408, 643);
            this.Predydushaya.Name = "Predydushaya";
            this.Predydushaya.Size = new System.Drawing.Size(195, 50);
            this.Predydushaya.TabIndex = 18;
            this.Predydushaya.Text = "Предыдущая";
            this.Predydushaya.UseVisualStyleBackColor = false;
            // 
            // Sledyushaya
            // 
            this.Sledyushaya.BackColor = System.Drawing.Color.Silver;
            this.Sledyushaya.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Sledyushaya.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Sledyushaya.Location = new System.Drawing.Point(609, 643);
            this.Sledyushaya.Name = "Sledyushaya";
            this.Sledyushaya.Size = new System.Drawing.Size(195, 50);
            this.Sledyushaya.TabIndex = 19;
            this.Sledyushaya.Text = "Следующая";
            this.Sledyushaya.UseVisualStyleBackColor = false;
            // 
            // Posledniya
            // 
            this.Posledniya.BackColor = System.Drawing.Color.Silver;
            this.Posledniya.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Posledniya.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Posledniya.Location = new System.Drawing.Point(847, 643);
            this.Posledniya.Name = "Posledniya";
            this.Posledniya.Size = new System.Drawing.Size(166, 50);
            this.Posledniya.TabIndex = 20;
            this.Posledniya.Text = "Последняя";
            this.Posledniya.UseVisualStyleBackColor = false;
            // 
            // PoiskBox
            // 
            this.PoiskBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.PoiskBox.Location = new System.Drawing.Point(12, 161);
            this.PoiskBox.Name = "PoiskBox";
            this.PoiskBox.Size = new System.Drawing.Size(479, 38);
            this.PoiskBox.TabIndex = 21;
            // 
            // izdeliyaDataGridView
            // 
            this.izdeliyaDataGridView.AutoGenerateColumns = false;
            this.izdeliyaDataGridView.BackgroundColor = System.Drawing.Color.Silver;
            this.izdeliyaDataGridView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.izdeliyaDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.izdeliyaDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4});
            this.izdeliyaDataGridView.DataSource = this.izdeliyaBindingSource;
            this.izdeliyaDataGridView.GridColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.izdeliyaDataGridView.Location = new System.Drawing.Point(216, 389);
            this.izdeliyaDataGridView.Name = "izdeliyaDataGridView";
            this.izdeliyaDataGridView.RowHeadersWidth = 51;
            this.izdeliyaDataGridView.RowTemplate.Height = 24;
            this.izdeliyaDataGridView.Size = new System.Drawing.Size(746, 196);
            this.izdeliyaDataGridView.TabIndex = 21;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Cod";
            this.dataGridViewTextBoxColumn1.HeaderText = "Код";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.Width = 125;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Vid_izdeliya";
            this.dataGridViewTextBoxColumn2.HeaderText = "Вид изделия";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Width = 125;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Stoimost";
            this.dataGridViewTextBoxColumn3.HeaderText = "Стоимость";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.Width = 125;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Osnovnoi_material";
            this.dataGridViewTextBoxColumn4.HeaderText = "Материал";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.Width = 125;
            // 
            // Poisk
            // 
            this.Poisk.BackColor = System.Drawing.Color.Silver;
            this.Poisk.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Poisk.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Poisk.Location = new System.Drawing.Point(497, 161);
            this.Poisk.Name = "Poisk";
            this.Poisk.Size = new System.Drawing.Size(139, 38);
            this.Poisk.TabIndex = 22;
            this.Poisk.Text = "Поиск";
            this.Poisk.UseVisualStyleBackColor = false;
            this.Poisk.Click += new System.EventHandler(this.Poisk_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Silver;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button1.Location = new System.Drawing.Point(714, 161);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(198, 38);
            this.button1.TabIndex = 23;
            this.button1.Text = "Сортировать";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Silver;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button2.Location = new System.Drawing.Point(957, 161);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(198, 38);
            this.button2.TabIndex = 24;
            this.button2.Text = "Фильтр";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // Izdeliya
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1182, 753);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Poisk);
            this.Controls.Add(this.izdeliyaDataGridView);
            this.Controls.Add(this.PoiskBox);
            this.Controls.Add(this.Posledniya);
            this.Controls.Add(this.Sledyushaya);
            this.Controls.Add(this.Predydushaya);
            this.Controls.Add(this.Sohranit);
            this.Controls.Add(this.Ydalit);
            this.Controls.Add(this.Dobavit);
            this.Controls.Add(this.Pervaya);
            this.Controls.Add(this.Zagolovok);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.Nazad);
            this.Controls.Add(this.Shapka);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Izdeliya";
            this.Text = "Изделия";
            this.Load += new System.EventHandler(this.Izdeliya_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dE_Bibilov_17DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.izdeliyaBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.izdeliyaDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Zagolovok;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button Nazad;
        private System.Windows.Forms.Label Shapka;
        private DE_Bibilov_17DataSet dE_Bibilov_17DataSet;
        private System.Windows.Forms.BindingSource izdeliyaBindingSource;
        private DE_Bibilov_17DataSetTableAdapters.IzdeliyaTableAdapter izdeliyaTableAdapter;
        private DE_Bibilov_17DataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.Button Pervaya;
        private System.Windows.Forms.Button Dobavit;
        private System.Windows.Forms.Button Ydalit;
        private System.Windows.Forms.Button Sohranit;
        private System.Windows.Forms.Button Predydushaya;
        private System.Windows.Forms.Button Sledyushaya;
        private System.Windows.Forms.Button Posledniya;
        private System.Windows.Forms.TextBox PoiskBox;
        private System.Windows.Forms.DataGridView izdeliyaDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.Button Poisk;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
    }
}