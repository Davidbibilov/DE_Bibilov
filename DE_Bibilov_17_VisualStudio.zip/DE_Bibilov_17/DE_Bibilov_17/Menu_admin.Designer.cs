﻿
namespace DE_Bibilov_17
{
    partial class Menu_admin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Menu_admin));
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Vyhod = new System.Windows.Forms.Button();
            this.Shapka = new System.Windows.Forms.Label();
            this.Izdeliya = new System.Windows.Forms.Button();
            this.Zakazy = new System.Windows.Forms.Button();
            this.Klienty = new System.Windows.Forms.Button();
            this.Sotrudniki = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(417, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(402, 72);
            this.label1.TabIndex = 9;
            this.label1.Text = "Меню";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pictureBox1.Image = global::DE_Bibilov_17.Properties.Resources.free_icon_double_bed_59284341;
            this.pictureBox1.Location = new System.Drawing.Point(1043, 24);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(114, 96);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 8;
            this.pictureBox1.TabStop = false;
            // 
            // Vyhod
            // 
            this.Vyhod.BackColor = System.Drawing.Color.Silver;
            this.Vyhod.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Vyhod.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Vyhod.Location = new System.Drawing.Point(13, 46);
            this.Vyhod.Name = "Vyhod";
            this.Vyhod.Size = new System.Drawing.Size(250, 50);
            this.Vyhod.TabIndex = 7;
            this.Vyhod.Text = "Выйти";
            this.Vyhod.UseVisualStyleBackColor = false;
            this.Vyhod.Click += new System.EventHandler(this.Vyhod_Click);
            // 
            // Shapka
            // 
            this.Shapka.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Shapka.Location = new System.Drawing.Point(-3, 0);
            this.Shapka.Name = "Shapka";
            this.Shapka.Size = new System.Drawing.Size(1189, 143);
            this.Shapka.TabIndex = 6;
            this.Shapka.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Izdeliya
            // 
            this.Izdeliya.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Izdeliya.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Izdeliya.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Izdeliya.ForeColor = System.Drawing.Color.White;
            this.Izdeliya.Location = new System.Drawing.Point(276, 262);
            this.Izdeliya.Name = "Izdeliya";
            this.Izdeliya.Size = new System.Drawing.Size(326, 70);
            this.Izdeliya.TabIndex = 10;
            this.Izdeliya.Text = "Изделия";
            this.Izdeliya.UseVisualStyleBackColor = false;
            this.Izdeliya.Click += new System.EventHandler(this.Izdeliya_Click);
            // 
            // Zakazy
            // 
            this.Zakazy.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Zakazy.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Zakazy.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Zakazy.ForeColor = System.Drawing.Color.White;
            this.Zakazy.Location = new System.Drawing.Point(632, 262);
            this.Zakazy.Name = "Zakazy";
            this.Zakazy.Size = new System.Drawing.Size(326, 70);
            this.Zakazy.TabIndex = 11;
            this.Zakazy.Text = "Заказы";
            this.Zakazy.UseVisualStyleBackColor = false;
            this.Zakazy.Click += new System.EventHandler(this.Zakazy_Click);
            // 
            // Klienty
            // 
            this.Klienty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Klienty.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Klienty.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Klienty.ForeColor = System.Drawing.Color.White;
            this.Klienty.Location = new System.Drawing.Point(276, 359);
            this.Klienty.Name = "Klienty";
            this.Klienty.Size = new System.Drawing.Size(326, 70);
            this.Klienty.TabIndex = 12;
            this.Klienty.Text = "Клиенты";
            this.Klienty.UseVisualStyleBackColor = false;
            this.Klienty.Click += new System.EventHandler(this.Klienty_Click);
            // 
            // Sotrudniki
            // 
            this.Sotrudniki.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Sotrudniki.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Sotrudniki.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Sotrudniki.ForeColor = System.Drawing.Color.White;
            this.Sotrudniki.Location = new System.Drawing.Point(632, 359);
            this.Sotrudniki.Name = "Sotrudniki";
            this.Sotrudniki.Size = new System.Drawing.Size(326, 70);
            this.Sotrudniki.TabIndex = 13;
            this.Sotrudniki.Text = "Сотрудники";
            this.Sotrudniki.UseVisualStyleBackColor = false;
            this.Sotrudniki.Click += new System.EventHandler(this.Sotrudniki_Click);
            // 
            // Menu_admin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1182, 553);
            this.Controls.Add(this.Sotrudniki);
            this.Controls.Add(this.Klienty);
            this.Controls.Add(this.Zakazy);
            this.Controls.Add(this.Izdeliya);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.Vyhod);
            this.Controls.Add(this.Shapka);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Menu_admin";
            this.Text = "Меню";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button Vyhod;
        private System.Windows.Forms.Label Shapka;
        private System.Windows.Forms.Button Izdeliya;
        private System.Windows.Forms.Button Zakazy;
        private System.Windows.Forms.Button Klienty;
        private System.Windows.Forms.Button Sotrudniki;
    }
}