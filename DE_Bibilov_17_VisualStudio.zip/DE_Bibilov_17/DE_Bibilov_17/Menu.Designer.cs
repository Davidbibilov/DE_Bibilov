﻿
namespace DE_Bibilov_17
{
    partial class Menu
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Menu));
            this.Vyhod = new System.Windows.Forms.Button();
            this.Shapka = new System.Windows.Forms.Label();
            this.Avtorizaciya = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Zagolovok = new System.Windows.Forms.Label();
            this.Izdeliya = new System.Windows.Forms.Button();
            this.Sotrudniki = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // Vyhod
            // 
            this.Vyhod.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Vyhod.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Vyhod.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Vyhod.ForeColor = System.Drawing.Color.White;
            this.Vyhod.Location = new System.Drawing.Point(12, 491);
            this.Vyhod.Name = "Vyhod";
            this.Vyhod.Size = new System.Drawing.Size(250, 50);
            this.Vyhod.TabIndex = 0;
            this.Vyhod.Text = "Выйти";
            this.Vyhod.UseVisualStyleBackColor = false;
            this.Vyhod.Click += new System.EventHandler(this.Vyhod_Click);
            // 
            // Shapka
            // 
            this.Shapka.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Shapka.Location = new System.Drawing.Point(-4, -1);
            this.Shapka.Name = "Shapka";
            this.Shapka.Size = new System.Drawing.Size(1189, 143);
            this.Shapka.TabIndex = 1;
            this.Shapka.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Avtorizaciya
            // 
            this.Avtorizaciya.BackColor = System.Drawing.Color.Silver;
            this.Avtorizaciya.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Avtorizaciya.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Avtorizaciya.Location = new System.Drawing.Point(12, 45);
            this.Avtorizaciya.Name = "Avtorizaciya";
            this.Avtorizaciya.Size = new System.Drawing.Size(250, 50);
            this.Avtorizaciya.TabIndex = 2;
            this.Avtorizaciya.Text = "Авторизация";
            this.Avtorizaciya.UseVisualStyleBackColor = false;
            this.Avtorizaciya.Click += new System.EventHandler(this.Avtorizaciya_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pictureBox1.Image = global::DE_Bibilov_17.Properties.Resources.free_icon_double_bed_59284341;
            this.pictureBox1.Location = new System.Drawing.Point(1042, 23);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(114, 96);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // Zagolovok
            // 
            this.Zagolovok.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Zagolovok.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Zagolovok.ForeColor = System.Drawing.Color.White;
            this.Zagolovok.Location = new System.Drawing.Point(406, 23);
            this.Zagolovok.Name = "Zagolovok";
            this.Zagolovok.Size = new System.Drawing.Size(402, 72);
            this.Zagolovok.TabIndex = 4;
            this.Zagolovok.Text = "Меню";
            this.Zagolovok.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Izdeliya
            // 
            this.Izdeliya.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Izdeliya.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Izdeliya.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Izdeliya.ForeColor = System.Drawing.Color.White;
            this.Izdeliya.Location = new System.Drawing.Point(263, 277);
            this.Izdeliya.Name = "Izdeliya";
            this.Izdeliya.Size = new System.Drawing.Size(326, 70);
            this.Izdeliya.TabIndex = 5;
            this.Izdeliya.Text = "Изделия";
            this.Izdeliya.UseVisualStyleBackColor = false;
            this.Izdeliya.Click += new System.EventHandler(this.Izdeliya_Click);
            // 
            // Sotrudniki
            // 
            this.Sotrudniki.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Sotrudniki.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Sotrudniki.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Sotrudniki.ForeColor = System.Drawing.Color.White;
            this.Sotrudniki.Location = new System.Drawing.Point(638, 277);
            this.Sotrudniki.Name = "Sotrudniki";
            this.Sotrudniki.Size = new System.Drawing.Size(326, 70);
            this.Sotrudniki.TabIndex = 6;
            this.Sotrudniki.Text = "Сотрудники";
            this.Sotrudniki.UseVisualStyleBackColor = false;
            this.Sotrudniki.Click += new System.EventHandler(this.Sotrudniki_Click);
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1182, 553);
            this.Controls.Add(this.Sotrudniki);
            this.Controls.Add(this.Izdeliya);
            this.Controls.Add(this.Zagolovok);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.Avtorizaciya);
            this.Controls.Add(this.Shapka);
            this.Controls.Add(this.Vyhod);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Menu";
            this.Text = "Меню";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button Vyhod;
        private System.Windows.Forms.Label Shapka;
        private System.Windows.Forms.Button Avtorizaciya;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label Zagolovok;
        private System.Windows.Forms.Button Izdeliya;
        private System.Windows.Forms.Button Sotrudniki;
    }
}

