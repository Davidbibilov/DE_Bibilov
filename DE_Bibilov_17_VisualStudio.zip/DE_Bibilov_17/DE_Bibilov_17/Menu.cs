﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DE_Bibilov_17
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
        }

        private void Avtorizaciya_Click(object sender, EventArgs e)
        {
            Avtorizaciya fm = new Avtorizaciya();
            fm.Show();
            this.Hide();
        }

        private void Izdeliya_Click(object sender, EventArgs e)
        {
            Izdeliya fm = new Izdeliya();
            fm.Show();
            this.Hide();
        }

        private void Sotrudniki_Click(object sender, EventArgs e)
        {
            Sotrudniki fm = new Sotrudniki();
            fm.Show();
            this.Hide();
        }

        private void Vyhod_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
