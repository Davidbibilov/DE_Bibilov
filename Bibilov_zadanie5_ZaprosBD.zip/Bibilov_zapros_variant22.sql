Create database Bibilov_Zapros_variant22
go

Use Bibilov_Zapros_variant22
go
create table Facultet
(
naimenovanie_faculteta Varchar (60) not null,
FIO_dekana Varchar (60) not null,
Nomer_komnaty int Primary key not null,
Nomer_korpusa int not null,
Telefon Int not null
)



Use Bibilov_Zapros_variant22
go
create table Kafedra
(
Nazvanie_kafedry Varchar(60) Primary key not null,
FIO_zavedyushego Varchar(60) not null,
Nomer_komnaty int FOREIGN KEY REFERENCES Facultet(Nomer_komnaty) not null,
Nomer_korpusa int not null,
Telefon int not null,
Kolichestvo_prepodavatelei int not null
)



Use Bibilov_Zapros_variant22
go
create table Prepodavateli
(
Familiya Varchar(60) Primary key not null,
Imya Varchar(60) not null,
Otchestvo Varchar(60) not null,
Nazvanie_kafedry Varchar(60) not null,
God_rozhdeniya int not null,
God_postypleniya_na_raboty int not null,
Stzh Varchar(60) not null,
Dolzhnost Varchar(60) not null,
Pol Varchar(60) not null,
Gorod Varchar(60) not null
)



Use Bibilov_Zapros_variant22
go
create table Discipliny
(
Nazvanie_discipliny Varchar(60) Primary key not null,
Kolichestvo_chasov int not null,
Cikl_disciplin int not null
)




Use Bibilov_Zapros_variant22
go
create table Uchebnaya_nagruzka
(
Prepodavatel Varchar(60) Primary key not null,
Nazvanie_discipliny Varchar(60) FOREIGN KEY REFERENCES Discipliny(Nazvanie_discipliny) not null,
Uchebnyi_god Varchar(60) not null,
Semestr int not null,
Gruppy Varchar(60) not null,
Kolichestvo_studentov int not null,
Vid_itogovogo_kontrolya Varchar(60) not null
)



